 </a></li>
          <li class="nav-item"><a class="nav-link" href="registra usuario.php">registra usuario</a></li>
          <li class="nav-item"><a class="nav-link" href="consultar usuario.php">consultar usuario</a></li>
          <li class="nav-item"><a class="nav-link" href="editar usuario.php">editar usuario</a></li>
          <li class="nav-item"><a class="nav-link" href="eliminar usuario.php">eliminar usuario</a></li>
            <svg class="bi" width="24" height="24"><use xlink:href="#cart"/></svg>
          </a></li>