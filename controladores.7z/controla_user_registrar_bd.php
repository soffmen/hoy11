<?php
 //paso1
//importar o llamar la conexion a la BD/DB
require "../config/conexion.php";


//paso 2
//Captura variables
$nombre = $_POST["nombre"];
$ducumento = $_POST["ducumento"];

//paso 3
//sentencia SQL
$sql = "INSERT INTO usuarios(fecha_sys, nombre, ducumento) 
VALUES 
(now(),'".$nombre."','".$ducumento."')";


//paso 4 ejecutar el sql
//echo $sql;
if($dbh->query($sql))
{
   echo "exito";
}else
{
    echo "error";
}


?>







