<?php
 //paso1
//importar o llamar la conexion a la BD/DB
require "../config/conexion.php";


//paso 3
//sentencia SQL
$sql = "SELECT
id,fecha_sys, nombre, ducumento
FROM
usuarios
WHERE 1";

//paso 4
foreach($dbh->query($sql) as $row)
{
    echo "nombre= ".$row[0]." - ducumento=".$row['ducumento']."<br>";
}
//acceder a un arreglo por asiciacion
//aceder por un arreglo por posicio


?>