<?php
 //paso1
//importar o llamar la conexion a la BD/DB
require "../config/conexion.php";


//paso 2
//Captura variables
$documento = $_POST["documento"];

//paso 3
//sentencia SQL
$sql = "DELETE FROM 
usuarios
WHERE ducumento = '".$documento."' ";

//paso 4 ejecutar el sql
if($dbh->query($sql))
{
   echo "eliminacion exitoso";
}else
{
    echo "error";
}

?>
